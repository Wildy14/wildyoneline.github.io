﻿Module Module1

    Sub Main()
        Console.Title = "Theme Park Sercurity System"

        Console.ForegroundColor = ConsoleColor.White

userName:

        Console.ForegroundColor = ConsoleColor.White

        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)

        Console.Clear()

        Dim username As String = "TP ADMIN"
        Console.ForegroundColor = ConsoleColor.Cyan
        Console.WriteLine("----------")
        Console.ForegroundColor = ConsoleColor.White
        Console.WriteLine("User Name:")
        Console.ForegroundColor = ConsoleColor.Cyan
        Console.WriteLine("----------")
        Console.ForegroundColor = ConsoleColor.White
        Dim usernameInput = Console.ReadLine
        If CStr(usernameInput).ToUpper = username Then


            GoTo password

        Else

            GoTo userNameBad

        End If
userNameBad:
        Console.ForegroundColor = ConsoleColor.White

        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)

        Console.Clear()
        Console.ForegroundColor = ConsoleColor.Cyan
        Console.WriteLine("----------------------------------------------------")
        Console.ForegroundColor = ConsoleColor.White
        Console.WriteLine("Your User Name is incorrect press enter to try again")
        Console.ForegroundColor = ConsoleColor.Cyan
        Console.WriteLine("----------------------------------------------------")
        Console.ForegroundColor = ConsoleColor.White
        Console.ReadLine()

        GoTo userName

password:
        Console.ForegroundColor = ConsoleColor.White

        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)

        Console.Clear()

        Console.ForegroundColor = ConsoleColor.White

        Dim password As String = "THEME PARK"
        Console.ForegroundColor = ConsoleColor.Cyan
        Console.WriteLine("--------")
        Console.ForegroundColor = ConsoleColor.White
        Console.WriteLine("Password")
        Console.ForegroundColor = ConsoleColor.Cyan
        Console.WriteLine("--------")
        Console.ForegroundColor = ConsoleColor.White
        Dim passwordInput = Console.ReadLine
        If CStr(passwordInput).ToUpper = password Then

            GoTo DisplayBox

        Else

            GoTo passwordBad

        End If

passwordBad:

        Console.ForegroundColor = ConsoleColor.White

        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)

        Console.Clear()
        Console.ForegroundColor = ConsoleColor.Cyan
        Console.WriteLine("------------------------------------------------")
        Console.ForegroundColor = ConsoleColor.White
        Console.WriteLine("Your Password is incorrect press enter try again")
        Console.ForegroundColor = ConsoleColor.Cyan
        Console.WriteLine("------------------------------------------------")
        Console.ForegroundColor = ConsoleColor.White
        Console.ReadLine()

        GoTo password

DisplayBox:

        Console.Clear()

        Dim preference As String
        Dim rideTimes1 As Integer
        Dim rideTimes2 As Integer
        Dim rideTimes3 As Integer
        Dim rideTimes4 As Integer
        Dim rideTimes5 As Integer
        Dim population As Integer

        Console.ForegroundColor = ConsoleColor.White

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)

        Console.Clear()

        Console.ForegroundColor = ConsoleColor.Cyan
        System.Threading.Thread.Sleep(125)
        Console.WriteLine("------------------------------------------------------------------")
        Console.ForegroundColor = ConsoleColor.White
        System.Threading.Thread.Sleep(125)
        Console.WriteLine("Please Enter in what operation you would like:")
        System.Threading.Thread.Sleep(125)
        Console.WriteLine("1: Update Ride Times")
        System.Threading.Thread.Sleep(125)
        Console.WriteLine("2: Transit current ride times")
        System.Threading.Thread.Sleep(125)
        Console.WriteLine("3: Enter the number of customers who have arrived in the last hour")
        System.Threading.Thread.Sleep(125)
        Console.WriteLine("4: Trasit current population")
        System.Threading.Thread.Sleep(125)
        Console.WriteLine("5: To go back to main menu")
        Console.ForegroundColor = ConsoleColor.Cyan
        System.Threading.Thread.Sleep(125)
        Console.WriteLine("------------------------------------------------------------------")
        Console.ForegroundColor = ConsoleColor.White

        preference = CStr(Console.ReadLine)

        If preference = "5" Then

            GoTo DisplayBox

        End If

        If preference = "1" Then
            Console.Clear()

            Console.ForegroundColor = ConsoleColor.White

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(250)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("------------------")
            Console.ForegroundColor = ConsoleColor.White
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Update The Twister")
            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("------------------")
            Console.ForegroundColor = ConsoleColor.White
            rideTimes1 = rideTimes1 + CInt(Console.ReadLine())

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.White

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(250)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("-----------------------")
            Console.ForegroundColor = ConsoleColor.White
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Update The Horror Wheel")
            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("-----------------------")
            Console.ForegroundColor = ConsoleColor.White
            rideTimes2 = rideTimes2 + CInt(Console.ReadLine())

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.White

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(250)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("------------------------")
            Console.ForegroundColor = ConsoleColor.White
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Update THe Hall of Tunes")
            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("------------------------")
            Console.ForegroundColor = ConsoleColor.White
            rideTimes3 = rideTimes3 + CInt(Console.ReadLine())

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.White

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(250)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("--------------------------")
            Console.ForegroundColor = ConsoleColor.White
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Update The Coaster Toaster")
            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("--------------------------")
            Console.ForegroundColor = ConsoleColor.White
            rideTimes4 = rideTimes4 + CInt(Console.ReadLine())

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.White

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(250)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("---------------")
            Console.ForegroundColor = ConsoleColor.White
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Update The Omen")
            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("---------------")
            Console.ForegroundColor = ConsoleColor.White
            rideTimes5 = rideTimes5 + CInt(Console.ReadLine())

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.White

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(250)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("------------------")
            Console.ForegroundColor = ConsoleColor.White
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Press 5 to go back")
            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("------------------")

            Console.ReadKey()

            GoTo DisplayBox

        End If

        If preference = "2" Then

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.White

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(250)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("----------------------------")
            Console.ForegroundColor = ConsoleColor.White
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("The Twister: " & rideTimes1 & " mins")
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("The Horror Wheel: " & rideTimes2 & " mins")
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("The Hall of Tunes: " & rideTimes3 & " mins")
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("The Coaster Toaster: " & rideTimes4 & " mins")
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("The Omen: " & rideTimes5 & " mins")
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Press 5 to go back")
            System.Threading.Thread.Sleep(125)
            Console.ForegroundColor = ConsoleColor.Cyan
            Console.WriteLine("----------------------------")

            Console.ReadKey()

            GoTo DisplayBox

        End If

        If preference = "3" Then

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.White

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(250)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("------------------------------------------------------------")
            Console.ForegroundColor = ConsoleColor.White
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Enter the number of people that have entend in the last hour")
            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("------------------------------------------------------------")
            Console.ForegroundColor = ConsoleColor.White
            population = population + CInt(Console.ReadLine())

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.White

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(250)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("------------------")
            Console.ForegroundColor = ConsoleColor.White
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Press 5 to go back")
            System.Threading.Thread.Sleep(125)
            Console.ForegroundColor = ConsoleColor.Cyan
            Console.WriteLine("------------------")
            Console.ReadKey()

            GoTo DisplayBox

        End If

        If preference = "4" Then

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.White

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(250)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("--------------------------------")
            Console.ForegroundColor = ConsoleColor.White
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("The population of the park is: " & population & " people")
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Press 5 to go back")
            System.Threading.Thread.Sleep(125)
            Console.ForegroundColor = ConsoleColor.Cyan
            Console.WriteLine("--------------------------------")

            Console.ReadKey()

            GoTo DisplayBox

        End If

    End Sub


End Module
