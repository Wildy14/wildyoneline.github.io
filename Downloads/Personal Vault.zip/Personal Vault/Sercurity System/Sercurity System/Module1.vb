﻿Module Module1

    Sub Main()
        Console.Title = "Sercurity System"

        Console.ForegroundColor = ConsoleColor.White

userName:

        Console.ForegroundColor = ConsoleColor.White

        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)

        Console.Clear()

        Dim username As String = "ADMIN"
        Console.ForegroundColor = ConsoleColor.Cyan
        Console.WriteLine("----------")
        Console.ForegroundColor = ConsoleColor.White
        Console.WriteLine("User Name:")
        Console.ForegroundColor = ConsoleColor.Cyan
        Console.WriteLine("----------")
        Console.ForegroundColor = ConsoleColor.White
        Dim usernameInput = Console.ReadLine
        If CStr(usernameInput).ToUpper = username Then


            GoTo password

        Else

            GoTo userNameBad

        End If
userNameBad:
        Console.ForegroundColor = ConsoleColor.White

        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)

        Console.Clear()
        Console.ForegroundColor = ConsoleColor.Cyan
        Console.WriteLine("----------------------------------------------------")
        Console.ForegroundColor = ConsoleColor.White
        Console.WriteLine("Your User Name is incorrect press enter to try again")
        Console.ForegroundColor = ConsoleColor.Cyan
        Console.WriteLine("----------------------------------------------------")
        Console.ReadLine()

        GoTo userName

password:
        Console.ForegroundColor = ConsoleColor.White

        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)

        Console.Clear()

        Console.ForegroundColor = ConsoleColor.White

        Dim password As String = "VAULT"
        Console.ForegroundColor = ConsoleColor.Cyan
        Console.WriteLine("--------")
        Console.ForegroundColor = ConsoleColor.White
        Console.WriteLine("Password")
        Console.ForegroundColor = ConsoleColor.Cyan
        Console.WriteLine("--------")
        Console.ForegroundColor = ConsoleColor.White
        Dim passwordInput = Console.ReadLine
        If CStr(passwordInput).ToUpper = password Then

            GoTo DisplayBox

        Else

            GoTo passwordBad

        End If

passwordBad:

        Console.ForegroundColor = ConsoleColor.White

        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)

        Console.Clear()
        Console.ForegroundColor = ConsoleColor.Cyan
        Console.WriteLine("------------------------------------------------")
        Console.ForegroundColor = ConsoleColor.White
        Console.WriteLine("Your Password is incorrect press enter try again")
        Console.ForegroundColor = ConsoleColor.Cyan
        Console.WriteLine("------------------------------------------------")
        Console.ReadLine()

        GoTo password

DisplayBox:

        Console.Clear()

        Dim preference As String

        Console.ForegroundColor = ConsoleColor.White

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait.")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait..")
        System.Threading.Thread.Sleep(125)
        Console.Clear()

        Console.WriteLine("Please Wait...")
        System.Threading.Thread.Sleep(125)

        Console.Clear()

        Console.ForegroundColor = ConsoleColor.Cyan
        System.Threading.Thread.Sleep(125)
        Console.WriteLine("---------------------------------------------------------------")
        Console.ForegroundColor = ConsoleColor.White
        System.Threading.Thread.Sleep(125)
        Console.WriteLine("Welcome to your sercurity system what would you like to access?")
        System.Threading.Thread.Sleep(125)
        Console.WriteLine("1: Personal Passwords")
        System.Threading.Thread.Sleep(125)
        Console.WriteLine("2: Credit Card Deatails")
        System.Threading.Thread.Sleep(125)
        Console.WriteLine("3: Personal Address")
        System.Threading.Thread.Sleep(125)
        Console.WriteLine("4: To go back to main menu")
        Console.ForegroundColor = ConsoleColor.Cyan
        System.Threading.Thread.Sleep(125)
        Console.WriteLine("---------------------------------------------------------------")
        Console.ForegroundColor = ConsoleColor.White
        preference = CStr(Console.ReadLine)

        If preference = "4" Then

            GoTo DisplayBox

        End If

        If preference = "1" Then

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.White

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("--------------------------------------------")
            Console.ForegroundColor = ConsoleColor.White
            Console.WriteLine("Welcome to your personal Passwords data base")
            Console.WriteLine("Press 4 to go back")

            Console.WriteLine()

            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Gmail: Password 1")
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Xbox: Password 2")
            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("--------------------------------------------")
            Console.ForegroundColor = ConsoleColor.White
            Console.ReadKey()

            GoTo DisplayBox

        End If

        If preference = "2" Then

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.White

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(250)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("-----------------------------------")
            Console.ForegroundColor = ConsoleColor.White
            Console.WriteLine("Welcome to your Credit Card data base")
            Console.WriteLine("Press 4 to go back")

            Console.WriteLine()

            System.Threading.Thread.Sleep(125)
            Console.WriteLine("NatWest VISA")
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Card Number: 9999 9999 9999 9999 ")
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Exires: 99/99")
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Sercurity Code: 999")
            System.Threading.Thread.Sleep(125)
            Console.ForegroundColor = ConsoleColor.Cyan
            Console.WriteLine("-----------------------------------")

            Console.ReadKey()

            GoTo DisplayBox

        End If

        If preference = "3" Then

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.White

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(250)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait.")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait..")
            System.Threading.Thread.Sleep(125)
            Console.Clear()

            Console.WriteLine("Please Wait...")
            System.Threading.Thread.Sleep(125)

            Console.Clear()

            Console.ForegroundColor = ConsoleColor.Cyan
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("----------------------------------------")
            Console.ForegroundColor = ConsoleColor.White
            Console.WriteLine("Welcome to your person address data base")
            Console.WriteLine("Press 4 to go back")

            Console.WriteLine()

            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Postcode: AB12 34C")
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Town/City: London")
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Street Address Line 1: Greater London")
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Street Address Line 2: Kings Cross")
            System.Threading.Thread.Sleep(125)
            Console.WriteLine("Country: England")
            System.Threading.Thread.Sleep(125)
            Console.ForegroundColor = ConsoleColor.Cyan
            Console.WriteLine("----------------------------------------")

            Console.ReadKey()

            GoTo DisplayBox

        End If

    End Sub


End Module
