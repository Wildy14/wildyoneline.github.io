--------------------------------------------
User Name: admin
Password: vault

Letter Case does not matter for this program
--------------------------------------------