--------------------------------------------
User Name: tp admin
Password: theme park

Letter Case does not matter for this program
--------------------------------------------